import java.time.LocalDate;
import java.time.Month;
import java.time.Period;

public class LocalDates {
	public static void main(String args[])
	{
		LocalDate myday1=LocalDate.of(2015, Month.JANUARY, 4);
		LocalDate myday2=LocalDate.of(2014, Month.JANUARY, 4);
		Period p = Period.between(myday2, myday1);
		System.out.println("Year : "+p.getYears()+"\n"+"Months : "+p.getMonths()+"\n"+"Days : "+p.getDays()+"\n");
		
	}
}
