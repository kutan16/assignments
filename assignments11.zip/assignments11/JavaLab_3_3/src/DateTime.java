import java.time.LocalDate;
import java.time.Month;
import java.time.Period;

public class DateTime 
{
	public static void inbetween(LocalDate myday, LocalDate today)
	{
		Period p=Period.between(myday, today);
		System.out.println("Year : "+p.getYears()+"\n"+"Months : "+p.getMonths()+"\n"+"Days : "+p.getDays());
	}
	public static void main(String args[])
	{
		LocalDate today = LocalDate.now();
		LocalDate myday = LocalDate.of(2015, Month.JANUARY, 4);
		inbetween(myday,today);
	}
}
