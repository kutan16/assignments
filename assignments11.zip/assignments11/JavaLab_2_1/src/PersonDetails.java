public class PersonDetails 
{
		public static void main(String[] args) 
		{
		// TODO Auto-generated method stub
		String firstname="Divya";
		String lastname="Bharathi";
		char gender = 'F';
		int age = 20;
		float weight = 85.55f;
		System.out.println("Person Details :");
		System.out.println("_________________");
		System.out.println("First name = "+firstname);
		System.out.println("Last name = "+lastname);
		System.out.println("Gender = "+gender);
		System.out.println("Age = "+age);
		System.out.println("Weight = "+weight);
	 }

	}
