
public abstract class Account 
{

	private long accNum;
	public double balance;
	private Person accHolder;
	
	public Account()
	{
		accNum=0;
		balance=0.0;
	}
	public Account(long accNum,double balance,Person accHolder)
	{
		this.accNum=accNum;
		this.balance=balance;
		this.accHolder=accHolder;
	}
	public long getAccNum() 
	{
		return accNum;
	}

	public void setAccNum(long accNum) 
	{
		this.accNum = accNum;
	}

	public Person getAccHolder() 
	{
		return accHolder;
	}

	public void setAccHolder(Person accHolder) 
	{
		this.accHolder = accHolder;
	}

	public void setBalance(double balance) 
	{
		this.balance = balance;
		if(balance<500)
		{
			System.out.println("Minimum balance not maintained");
		}
		else
		{
			System.out.println("Account is good");
		}
	}
	
	public void deposit(double amount)
	{
		balance=balance+amount;
		System.out.println(balance);
	}
	
	abstract public void withdraw(double amount);
	/*public void withdraw(double amount)
	{
		if((balance-amount)<0)
			System.out.println("Low account balance ");
		else
		{
			balance=balance-amount;
			System.out.println(balance);
		}
	}*/
	public double getBalance()
	{
		return balance;
	}
	@Override
	public String toString()
	{
		return "Account number : "+accNum+
				"\n"+"Account Balance : "+balance+
				"\n"+"Account holder - > \n"+
				"Name = "+accHolder.getName()+
				"\n"+"Age = "+accHolder.getAge()+"\n";
	}
}
