
public class PersonTest 
{
	private String firstname,lastname;
	private char gender;
	int phone;
	PersonTest() 
	{
		firstname="";
		lastname="";
		gender='\0';
		phone=0;
	}
	PersonTest(String f,String l,char g,int p) 
	{
		firstname=f;
		lastname=l;
		gender=g;
		phone=p;
	}
	
	public String getFirstName()
	{
		return firstname;
	}
	public void setFirstName(String k)
	{
		firstname=k;
	}
	
	public String getLastName()
	{
		return lastname;
	}
	public void setLastName(String k) 
	{
		lastname=k;
	}
	
	public char getGender()
	{
		return gender;
	}
	public void setGender(char k) 
	{
		gender=k;
	}
	
	public int getPhone()
	{
		return phone;
	}
	public void setPhone(int k) 
	{
		phone=k;
	}
	
}
