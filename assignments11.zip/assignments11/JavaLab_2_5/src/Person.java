
public class Person
{
	private String firstname,lastname;
	private int phone;
	Gender gender;
	Person() 
	{
		firstname="";
		lastname="";
		gender=null;
		phone=0;
	}
	Person(String firstname,String lastname,Gender gender,int p) 
	{
		this.firstname=firstname;
		this.lastname=lastname;
		this.gender=gender;
		this.phone=phone;
	}
	
	public String getFirstName() 
	{
		return firstname;
	}
	public void setFirstName(String k) 
	{
		firstname=k;
	}
	
	public String getLastName() 
	{
		return lastname;
	}
	public void setLastName(String k) 
	{
		lastname=k;
	}
	
	public Gender getGender()
	{
		return gender;
	}
	public void setGender(Gender k) 
	{
		gender=k;
	}
	
	public int getPhone() 
	{
		return phone;
	}
	public void setPhone(int k) 
	{
		phone=k;
	}
	
}
