import java.util.Scanner;


public class PersonTest 
{
	public static void main(String args[]) 
	{
		Gender gender = null;
		Scanner sc = new Scanner(System.in);
		PersonTest ob = new PersonTest();
		System.out.println("First Name ");
		String name1=sc.next();
		System.out.println("Last Name ");
		String name2=sc.next();
		System.out.println("Press 'M' for male"+"\n"+"Press 'F' for female");
		char index=sc.next().charAt(0);
		switch(index)
		{
			case 'm': 
				gender=Gender.Male;
				break;
			case 'f': 
				gender=Gender.Female;
				break;
			default:
				System.out.println("Gender not defined");
		}
		System.out.println("Phone ");
		int phone=sc.nextInt();
		System.out.println("Person Details"+"\n"+"________________");
		System.out.println("First Name = "+name1
				+"\n"+"Last Name = "+name2
				+"\n"+"Gender = "+gender+"\n"
				+"Phone = "+phone);
	}
}