import java.util.*;
public class StringOperation 
{	
	public static void OpConcat(String n) 
	{
		n=n.concat(n);
		System.out.println(n);
	}

	public static void OpReplace(String n)
	{
		String r="";
		for(int i=0;i<n.length();i++)
		{
			if(i%2!=0)
			{
				n=n.substring(0, i-1)+'#'+n.substring(i, n.length());
			}
		}
		System.out.println(n);
	}

	public void OpRemove(String n)
	{
		for(int i=0;i<n.length();i++)
		{
			
		}
	}

	public static void OpUpper(String n)
	{
		char c[]=n.toCharArray();
		for(int i=0;i<n.length();i=i+2)
		{
			c[i]=(char)(c[i]-'a'+'A');
		}
		System.out.println(c);
	}

	public static void main(String args[]) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a String : ");
		String n = sc.next();
		System.out.println("press 1 to add string to itself");
		System.out.println("press 2 to replace odd positions with #");
		System.out.println("press 3 to remove duplicate characters in string");
		System.out.println("press 4 to change odd characters to uppercase");
		int index = sc.nextInt();
		System.out.println();
		switch(index) 
		{
		case 1:	
			OpConcat(n);
			break;
		case 2:	
			OpReplace(n);
			break;
			//case 3:	

		case 4:	
			OpUpper(n);
			break;
		default: System.out.println("Wrong choice");
		}
	}
}


