
public class PersonTest 
{
	public static void main(String args[]) throws NameNotValidException 
	{
		Person ob = new Person();

			ob.setFirstName("nilotpal");
			ob.setLastName("");
			ob.setGender('M');
		
		System.out.println("Person Details"+"\n"+"________________");
		System.out.println("First Name = "+ob.getFirstName()+"\n"+"Last Name = "+ob.getLastName()+"\n"+"Gender = "+ob.getGender()+"\n");
	}
}