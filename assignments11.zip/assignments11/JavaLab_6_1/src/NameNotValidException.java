
@SuppressWarnings("serial")
public class NameNotValidException extends Exception
{
	public NameNotValidException()
	{
		super("name entered is not valid");
	}
}
