import java.util.Scanner;

public class WarrantyExpiry 
{
	public static void productDate()
	{
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter product purchase date in the following format : ");
		System.out.println("dd");
		System.out.println("mm");
		System.out.println("yyyy");
		int pDay = sc.nextInt();
		int pMonth = sc.nextInt();
		int pYear = sc.nextInt();
		
		System.out.println("Enter the warranty period in the following format : ");
		System.out.println("yyyy");
		System.out.println("mm");
		int wYear = sc.nextInt();
		int wMonth = sc.nextInt();
		
		int eDay;
		int eMonth;
		int eYear;
		eDay=pDay;
		eMonth=pMonth+wMonth;
		if(eMonth>12)
		{
			eMonth=eMonth-12;
		}
		eYear=pYear+wYear;
		
		System.out.println("Expiry Date is : ");
		System.out.println(eDay+"-"+eMonth+"-"+eYear);
	}
	public static void main(String args[])
	{
		productDate();
	}
}
