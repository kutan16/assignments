
public class TestAccount 
{
	public static void main(String args[])
	{
		Person s=new Person("Smith",14.f);
		Person k=new Person("Kathy",24.f);
		
		int accNum=(int)(Math.random()*100);
		Account smith=new Account(accNum,400,s);
		
		int accNum1=(int)(Math.random()*50);
		Account kathy = new Account(accNum1,1000,k);
		
		System.out.println("Deposited in Smith's account : ");
		smith.deposit(2000);
		System.out.println("Withdrawn from Kathy's account : ");
		kathy.withdraw(2000);
		
		System.out.println();
		System.out.println("Updated Balance : ");
		
		System.out.println(smith.toString());
		
		
		System.out.println(kathy.toString());
		
		
	}
}
